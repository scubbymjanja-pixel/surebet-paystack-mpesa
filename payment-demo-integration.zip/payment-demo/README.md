# Direct Paystack M-Pesa STK push demo

This folder adds a standalone web payment surface for the pasted VIP page. The Android/Pangle demo remains unchanged because it contains no web or server application.

## Flow

1. The customer taps one plan button and enters the Kenyan M-Pesa phone number in a popup.
2. `POST /api/payments/mpesa/initiate` runs on the server and calls Paystack `POST /charge` with:
   - `currency: KES`
   - `mobile_money.provider: mpesa`
   - `mobile_money.phone: +254...`
   - no card, Till, redirect, or alternate checkout channel
3. The customer approves the STK prompt on the phone.
4. The server accepts only a valid HMAC-SHA512 Paystack webhook and also exposes server-side transaction verification for the pending UI.
5. Fulfilment belongs in the marked webhook block and must be idempotent.

Paystack documents that M-Pesa charges are asynchronous, return `pay_offline`, require customer authorization, and expire after 180 seconds. The browser does not decide that payment succeeded.

## Run locally

```bash
cd payment-demo
cp .env.example .env
# Put your Paystack secret key in .env; never commit .env.
npm install
set -a; . ./.env; set +a
npm start
```

Open <http://localhost:3000>.

The local workspace has been configured with the user-provided live secret in the ignored `.env` file. It is not included in Git or the downloadable archive. Restart the service after changing `.env`.

Set the webhook URL in the Paystack dashboard to:

```text
https://YOUR_PUBLIC_HOST/api/paystack/webhook
```

A localhost URL cannot receive Paystack webhooks. For a real deployment, use HTTPS and a persistent database instead of the in-memory `charges` map.

## Keys

The pasted HTML contained a live-looking publishable key. It was intentionally not copied into the repository. Rotate/revoke it in Paystack if it has been exposed. A direct server-side `/charge` M-Pesa integration uses the **secret key only**; a publishable key is for client-side Paystack.js flows and must not be used as a substitute for server verification. Never put the secret key in HTML, Android resources, or client JavaScript.

## Tests

```bash
npm test
```
