import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeKenyanPhone, PLANS } from './server.js';

test('normalizes local Kenyan mobile numbers to E.164', () => {
  assert.equal(normalizeKenyanPhone('0722 000 000'), '+254722000000');
  assert.equal(normalizeKenyanPhone('0112-000-000'), '+254112000000');
  assert.equal(normalizeKenyanPhone('254722000000'), '+254722000000');
  assert.equal(normalizeKenyanPhone('+254722000000'), '+254722000000');
});

test('rejects invalid or non-Kenyan numbers', () => {
  assert.equal(normalizeKenyanPhone('071234567'), null);
  assert.equal(normalizeKenyanPhone('+12025550123'), null);
  assert.equal(normalizeKenyanPhone(''), null);
});

test('exposes only the configured plans', () => {
  assert.deepEqual(Object.keys(PLANS), ['platinum', 'gold', 'silver']);
  assert.equal(PLANS.platinum.amountKes, 1200);
});
