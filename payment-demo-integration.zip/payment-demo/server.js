import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const secretKey = process.env.PAYSTACK_SECRET_KEY;
const toleranceSeconds = Number(process.env.WEBHOOK_TOLERANCE_SECONDS || 300);
const charges = new Map();

const PLANS = Object.freeze({
  platinum: { name: 'Platinum Correct Score', amountKes: 1200 },
  gold: { name: 'Gold Daily', amountKes: 500 },
  silver: { name: 'Silver Basic', amountKes: 250 }
});

function jsonError(message, status = 400) {
  return { error: message, status };
}

function normalizeKenyanPhone(value) {
  const raw = String(value || '').replace(/[\s()-]/g, '');
  if (/^07\d{8}$/.test(raw) || /^01\d{8}$/.test(raw)) return `+254${raw.slice(1)}`;
  if (/^254(?:7|1)\d{8}$/.test(raw)) return `+${raw}`;
  if (/^\+254(?:7|1)\d{8}$/.test(raw)) return raw;
  return null;
}

function validEmail(value) {
  return typeof value === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

async function paystack(pathname, options = {}) {
  if (!secretKey) throw new Error('PAYSTACK_SECRET_KEY is not configured');
  const response = await fetch(`https://api.paystack.co${pathname}`, {
    ...options,
    headers: { Authorization: `Bearer ${secretKey}`, 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok || body.status === false) throw new Error(body.message || `Paystack request failed (${response.status})`);
  return body;
}

// Capture the raw request body so webhook signatures can be verified exactly.
app.use(express.json({ verify: (req, _res, buffer) => { req.rawBody = buffer; } }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/api/payments/mpesa/initiate', async (req, res) => {
  const { planId, phone, email } = req.body || {};
  const plan = PLANS[planId];
  const normalizedPhone = normalizeKenyanPhone(phone);
  if (!plan) return res.status(400).json(jsonError('Unknown plan.'));
  if (!normalizedPhone) return res.status(400).json(jsonError('Enter a valid Kenyan M-Pesa number.'));
  if (email !== undefined && !validEmail(email)) return res.status(400).json(jsonError('Enter a valid email address.'));

  const reference = `mpesa_${Date.now()}_${crypto.randomBytes(5).toString('hex')}`;
  const customerEmail = validEmail(email) ? email : `${reference}@payments.invalid`;
  try {
    const body = await paystack('/charge', {
      method: 'POST',
      body: JSON.stringify({
        email: customerEmail,
        amount: plan.amountKes * 100,
        currency: 'KES',
        reference,
        mobile_money: { phone: normalizedPhone, provider: 'mpesa' },
        metadata: { plan_id: planId, plan_name: plan.name, phone: normalizedPhone }
      })
    });
    const data = body.data || {};
    charges.set(reference, { planId, amountKes: plan.amountKes, status: data.status || 'pending', createdAt: Date.now() });
    return res.status(202).json({ reference, status: data.status, displayText: data.display_text || 'Please complete authorization on your phone.' });
  } catch (error) {
    return res.status(502).json(jsonError(error.message, 502));
  }
});

app.get('/api/payments/:reference', async (req, res) => {
  const reference = req.params.reference;
  if (!/^mpesa_[A-Za-z0-9_-]+$/.test(reference)) return res.status(400).json(jsonError('Invalid reference.'));
  const known = charges.get(reference);
  if (!known) return res.status(404).json(jsonError('Payment not found.', 404));
  try {
    const body = await paystack(`/transaction/verify/${encodeURIComponent(reference)}`, { method: 'GET' });
    const data = body.data || {};
    if (data.status === 'success') known.status = 'success';
    else if (['failed', 'abandoned', 'reversed'].includes(data.status)) known.status = data.status;
    return res.json({ reference, status: known.status, message: data.gateway_response || data.message || null });
  } catch (error) {
    return res.status(502).json(jsonError(error.message, 502));
  }
});

app.post('/api/paystack/webhook', (req, res) => {
  const signature = req.get('x-paystack-signature') || '';
  const rawBody = req.rawBody || Buffer.from('');
  if (!secretKey || !signature) return res.sendStatus(401);
  const expected = crypto.createHmac('sha512', secretKey).update(rawBody).digest('hex');
  const valid = signature.length === expected.length && crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  if (!valid) return res.sendStatus(401);
  const event = req.body || {};
  if (event.event === 'charge.success' && event.data?.reference) {
    const reference = event.data.reference;
    const known = charges.get(reference);
    if (known) known.status = 'success';
    // Fulfil the purchased service here, idempotently, after checking reference/amount/plan.
  }
  return res.sendStatus(200);
});

app.use((error, _req, res, _next) => {
  if (error instanceof SyntaxError) return res.status(400).json(jsonError('Invalid JSON.'));
  return res.status(500).json(jsonError('Unexpected server error.', 500));
});

if (process.env.NODE_ENV !== 'test') {
  if (!secretKey) console.warn('Warning: PAYSTACK_SECRET_KEY is not set; payment requests will fail.');
  app.listen(port, '0.0.0.0', () => console.log(`Payment demo listening on http://0.0.0.0:${port}`));
}

export { app, normalizeKenyanPhone, PLANS };
